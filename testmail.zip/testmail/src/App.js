import logo from './logo.svg';
import './App.css';
import SendReminderEmails from './SendReminderEmail';

function App() {
  return (
    <div className="App">
    <SendReminderEmails />   {/* Hiển thị trực tiếp component này */}
  </div>
  );
}

export default App;
